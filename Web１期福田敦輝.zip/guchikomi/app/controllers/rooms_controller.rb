class RoomsController < ApplicationController
end
