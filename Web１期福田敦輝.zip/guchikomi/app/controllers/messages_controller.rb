class MessagesController < ApplicationController
end
