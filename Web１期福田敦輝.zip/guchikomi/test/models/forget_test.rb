require 'test_helper'

class ForgetTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
